# object detection > 2024-10-14 9:23am
https://universe.roboflow.com/object-detection-bvxsa/object-detection-smge4

Provided by a Roboflow user
License: CC BY 4.0

