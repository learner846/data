# object detection > 2024-11-11 5:12pm
https://universe.roboflow.com/object-detection-bvxsa/object-detection-smge4

Provided by a Roboflow user
License: CC BY 4.0

